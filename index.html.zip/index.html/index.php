<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input data to prevent XSS attacks
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $message = htmlspecialchars($_POST['message']);

    // Define recipient email and subject
    $to = "lievanparojinog@gmail.com";  // Replace with your email address
    $subject = "New Message from Contact Form";

    // Create email body
    $body = "You have received a new message from the contact form.\n\n".
            "Name: $name\n".
            "Email: $email\n".
            "Message: \n$message";

    // Define email headers
    $headers = "From: $email";

    // Send email using PHP's mail function
    if (mail($to, $subject, $body, $headers)) {
        // Success message
        echo "<p>Message sent successfully! Thank you for contacting me.</p>";
    } else {
        // Failure message
        echo "<p>There was an error sending your message. Please try again.</p>";
    }
}
?>

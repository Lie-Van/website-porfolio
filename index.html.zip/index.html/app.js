document.addEventListener('DOMContentLoaded', () =>{
    const carousel = document.getElementById('carousel');
    const slides = carousel.children;
    const totalSlides = slides.length;
    let index = 0;

    function nextSlide() {
      index = (index + 1) % totalSlides; // Loop back to the first slide if at the last
      updateCarousel();
    }

    function prevSlide() {
      index = (index - 1 + totalSlides) % totalSlides; // Loop back to the last slide if at the first
      updateCarousel();
    }

    function updateCarousel() {
      const offset = -index * 100; // Move by 100% per slide
      carousel.style.transform = `translateX(${offset}%)`;
    }

    // Add event listeners for the buttons
    document.querySelector('.arrow.left').addEventListener('click', prevSlide);
    document.querySelector('.arrow.right').addEventListener('click', nextSlide);
  });